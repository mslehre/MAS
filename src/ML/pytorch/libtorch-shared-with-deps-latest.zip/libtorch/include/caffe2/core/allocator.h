#ifndef CAFFE2_CORE_ALLOCATOR_H_
#define CAFFE2_CORE_ALLOCATOR_H_
#include <c10/core/CPUAllocator.h>
#endif // CAFFE2_CORE_ALLOCATOR_H_
